//
//  ProgramSandbox.swift
//  GroovyMorningFM_MobileApp
//
//  Created by Eglantine Fonrose on 14/02/2025.
//

import SwiftUI

struct ProgramSandbox: View {
    var body: some View {
        Text("Lancer l'enregistrement de la chronique de Daniel Morin de 6h56 à 7h")
    }
}

#Preview {
    ProgramSandbox()
}
